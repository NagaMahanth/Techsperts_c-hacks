# How to push Receipt to GitHub

Follow these steps in order. Takes 5 minutes.

## STEP 1 — Create a GitHub account (if you don't have one)

Go to [github.com](https://github.com) → Sign up. Use a professional username (first-name-last-name or similar).

## STEP 2 — Create a new repository on GitHub

1. Click the **+** icon top-right → **New repository**
2. Repository name: `receipt-sdg12`
3. Description: `A satirical web experience for UN SDG 12. The planet does not send invoices. So we printed one for you.`
4. Set to **Public** (judges need to see it)
5. **DO NOT** check "Add a README" or ".gitignore" or "License" — you already have those
6. Click **Create repository**

GitHub will show you a page with commands. Keep that tab open.

---

## STEP 3 — Push your code (choose A or B)

### A) EASY WAY — GitHub Desktop (no terminal)

1. Download [GitHub Desktop](https://desktop.github.com/) → Install → Sign in
2. **File → Add Local Repository → Choose** the `receipt-sdg12` folder on your laptop
3. GitHub Desktop asks "Create a repository?" → **Create a repository**
4. Click **Publish repository** at the top → Uncheck "Keep this code private" → **Publish**

Done. Your code is on GitHub.

### B) FAST WAY — Terminal / Command line

Open Terminal (Mac) or Git Bash (Windows). Navigate to your project folder:

```bash
cd path/to/receipt-sdg12

# Initialize git
git init

# Set your identity (first time only)
git config user.name "Your Name"
git config user.email "your@email.com"

# Stage and commit everything
git add .
git commit -m "Initial commit: Receipt - UN SDG 12 hackathon project"

# Create main branch
git branch -M main

# Connect to GitHub (REPLACE with YOUR username)
git remote add origin https://github.com/YOUR-USERNAME/receipt-sdg12.git

# Push
git push -u origin main
```

GitHub will ask for authentication. If it asks for a password, use a **personal access token** instead:
- Go to github.com → Settings → Developer settings → Personal access tokens → Generate new (classic)
- Give it `repo` scope → Copy the token → paste as password

---

## STEP 4 — Enable GitHub Pages (free hosting, instant backup to Netlify)

1. On your repo's GitHub page → **Settings** tab
2. Left sidebar → **Pages**
3. Under "Source" → Branch: **main** → Folder: **/ (root)** → **Save**
4. Wait 30 seconds → scroll up — your live URL appears:
   `https://YOUR-USERNAME.github.io/receipt-sdg12/`

Now you have TWO live URLs: Netlify AND GitHub Pages. Submit whichever works.

---

## STEP 5 — Make it look professional

Before you submit, go to your repo page and:

1. **Add topics** (right side, click the gear next to "About")
   - `sdg12`, `hackathon`, `web-design`, `sustainability`, `html-css-js`, `receipt`, `climate`

2. **Set the "About" description**
   - `A satirical web experience that prints the hidden environmental cost of your weekly consumption. Built for UN SDG 12.`
   - Website: paste your Netlify or GitHub Pages URL

3. **Pin the repo on your profile** (optional)
   - Go to your GitHub profile → Customize your pins → add this repo

---

## STEP 6 — Customize the README before submission

Open `README.md` in VS Code (or on GitHub itself) and replace these placeholders:

- `[your-netlify-url-here]` → your actual live URL
- `[Your name]`, `[Member 2]`, `[Member 3]` → real names
- `[YOUR HACKATHON NAME]` → the actual event name

Commit the change:

```bash
git add README.md
git commit -m "Update README with team names and live URL"
git push
```

Or in GitHub Desktop: write a summary → **Commit** → **Push origin**.

---

## FINAL CHECKLIST (before submission)

Visit your GitHub repo URL and confirm:

- [ ] README displays nicely with headings, emojis, table of sources
- [ ] Live demo link in README works
- [ ] All 6 files visible: `index.html`, `styles.css`, `script.js`, `README.md`, `LICENSE`, `.gitignore`
- [ ] Repo is **public** (not private)
- [ ] GitHub Pages is enabled (optional but recommended)
- [ ] "About" has description + website link + topics

Your GitHub URL to submit will look like:
`https://github.com/YOUR-USERNAME/receipt-sdg12`

---

## If you get stuck

- **"Permission denied (publickey)"** → use HTTPS URL, not SSH
- **"Repository not found"** → double-check your username in the remote URL
- **"Updates were rejected"** → run `git pull origin main --allow-unrelated-histories` then push again

Good luck. Now push and win.
